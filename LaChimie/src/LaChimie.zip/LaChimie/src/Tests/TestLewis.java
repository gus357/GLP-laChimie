package Tests;

import Chimie.Repr�sentation;

public class TestLewis {
	public static void main (String[] args) {
		Repr�sentation r = new Repr�sentation();
		r.paint(null);
	}
}
