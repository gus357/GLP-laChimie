package Tests;

import Chimie.Definition;

public class TestDefiniton {
	public static void main (String []args) {
		new Definition();
	}
}
