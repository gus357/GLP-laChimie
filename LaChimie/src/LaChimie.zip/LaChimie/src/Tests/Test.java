package Tests;

import Chimie.U;

public class Test {
	
	public static void main (String [] args) {
		
		//Fenetre fen = new Fenetre("tableau de mendeliev");
	//	fen.init();
		
		U u = new U();
		
	}

}
