package Chimie;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ActionListener.ActionActinides;
import ActionListener.ActionBaryum;
import ActionListener.ActionB�rillium;
import ActionListener.ActionCalcium;
import ActionListener.ActionChrome;
import ActionListener.ActionC�sium;
import ActionListener.ActionDubnium;
import ActionListener.ActionFrancium;
import ActionListener.ActionHafnium;
import ActionListener.ActionHydrog�ne;
import ActionListener.ActionLanthanides;
import ActionListener.ActionLithium;
import ActionListener.ActionMagn�sium;
import ActionListener.ActionMangan�se;
import ActionListener.ActionMolibd�ne;
import ActionListener.ActionNobium;
import ActionListener.ActionPotassium;
import ActionListener.ActionRadium;
import ActionListener.ActionRubidium;
import ActionListener.ActionRutherfordium;
import ActionListener.ActionScandium;
import ActionListener.ActionSeaborgium;
import ActionListener.ActionSodium;
import ActionListener.ActionStrontium;
import ActionListener.ActionTantale;
import ActionListener.ActionTecht�nium;
import ActionListener.ActionTitane;
import ActionListener.ActionTungst�ne;
import ActionListener.ActionVanadium;
import ActionListener.ActionYttrium;
import ActionListener.ActionZirconcium;
import Data.ReadCsv;
import Chimie.imgAtome.*;

import javax.imageio.ImageIO;
import javax.print.DocFlavor.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class TableMende extends JFrame{
	//private static final long serialVersionUID = 1L;
	public TableMende() throws IOException{
		
    this.setTitle("Table de Mendelieve");
    this.setSize(2000, 2100);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
	this.getContentPane().setLayout(new FlowLayout());
	
    // première colonne
    
    JPanel cell1 = new JPanel();
    BufferedImage myPicture1 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/h.png"));
	ImageIcon image1 = new ImageIcon(myPicture1); 
    //cell1.setPreferredSize(new Dimension(150, 75));
    JButton but1 = new JButton ((image1));
    //but1.setPreferredSize(new Dimension (100,35));
	but1.addActionListener(new ActionHydrog�ne());
	but1.setToolTipText("Hydrog�ne");
	cell1.add(but1);
    
    JPanel cell2 = new JPanel();
    BufferedImage myPicture2 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Li.png"));
	ImageIcon image2 = new ImageIcon(myPicture2);
    //cell2.setPreferredSize(new Dimension(150, 75));
    JButton but2 = new JButton (image2);
    //but2.setPreferredSize(new Dimension (100,35));
	but2.addActionListener(new ActionLithium());
    cell2.add(but2);
    
    JPanel cell3 = new JPanel();
    BufferedImage myPicture3 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Na.png"));
	ImageIcon image3 = new ImageIcon(myPicture3);
    //cell3.setPreferredSize(new Dimension(150, 75));
    JButton but3 = new JButton (image3);
    //but3.setPreferredSize(new Dimension (100,35));
    but3.addActionListener(new ActionSodium());
    cell3.add(but3);
    
    JPanel cell4 = new JPanel();
    BufferedImage myPicture4 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/K.png"));
	ImageIcon image4 = new ImageIcon(myPicture4);
    //cell4.setPreferredSize(new Dimension(150, 75));
    JButton but4 = new JButton (image4);
    //but4.setPreferredSize(new Dimension (100,35));
    but4.addActionListener(new ActionPotassium());
    cell4.add(but4);
    
    JPanel cell5 = new JPanel();
    BufferedImage myPicture5 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Rb.png"));
	ImageIcon image5 = new ImageIcon(myPicture5);
    //cell5.setPreferredSize(new Dimension(150, 75));
    JButton but5 = new JButton (image5);
    //but5.setPreferredSize(new Dimension (100,35));
    but5.addActionListener(new ActionRubidium());
    cell5.add(but5);
    
    JPanel cell6 = new JPanel();
    BufferedImage myPicture6 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Cs.png"));
	ImageIcon image6 = new ImageIcon(myPicture6);
    //cell6.setPreferredSize(new Dimension(150, 75));
    JButton but6 = new JButton (image6);
    //but6.setPreferredSize(new Dimension (100,35));
    but6.addActionListener(new ActionC�sium());
    cell6.add(but6);
    
    JPanel cell7 = new JPanel();
    BufferedImage myPicture7 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Fr.png"));
	ImageIcon image7 = new ImageIcon(myPicture7);
   // cell7.setPreferredSize(new Dimension(150, 75));
    JButton but7 = new JButton (image7);
    //but7.setPreferredSize(new Dimension (100,35));
    but7.addActionListener(new ActionFrancium());
    cell7.add(but7);
    
    // deuxième colonne
    
    JPanel cell8 = new JPanel();
    BufferedImage myPicture8 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Be.png"));
	ImageIcon image8 = new ImageIcon(myPicture8);
    //cell8.setPreferredSize(new Dimension(150, 75));
    JButton but8 = new JButton (image8);
    //but8.setPreferredSize(new Dimension (100,35));
    but8.addActionListener(new ActionB�rillium());
    cell8.add(but8);
    
    JPanel cell9 = new JPanel();
    BufferedImage myPicture9 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Mg.png"));
	ImageIcon image9 = new ImageIcon(myPicture9);
    //cell9.setPreferredSize(new Dimension(150, 75));
    JButton but9 = new JButton (image9);
    //but9.setPreferredSize(new Dimension (100,35));
    but9.addActionListener(new ActionMagn�sium());
    cell9.add(but9);
    
    JPanel cell10 = new JPanel();
    BufferedImage myPicture10 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ca.png"));
	ImageIcon image10 = new ImageIcon(myPicture10);
   // cell10.setPreferredSize(new Dimension(150, 75));
    JButton but10 = new JButton (image10);
    //but10.setPreferredSize(new Dimension (100,35));
    but10.addActionListener(new ActionCalcium());
    cell10.add(but10);
    
    JPanel cell11 = new JPanel();
    BufferedImage myPicture11 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Sr.png"));
	ImageIcon image11 = new ImageIcon(myPicture11);
    //cell11.setPreferredSize(new Dimension(150, 75));
    JButton but11 = new JButton (image11);
    //but11.setPreferredSize(new Dimension (100,35));
    but11.addActionListener(new ActionStrontium());
    cell11.add(but11);
    
    JPanel cell12 = new JPanel();
    BufferedImage myPicture12 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ba.png"));
	ImageIcon image12 = new ImageIcon(myPicture12);
    //cell12.setPreferredSize(new Dimension(150, 75));
    JButton but12 = new JButton (image12);
   // but12.setPreferredSize(new Dimension (100,35));
    but12.addActionListener(new ActionBaryum());
    cell12.add(but12);
    
    JPanel cell13 = new JPanel();
    BufferedImage myPicture13 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ra.png"));
	ImageIcon image13 = new ImageIcon(myPicture13);
   // cell13.setPreferredSize(new Dimension(150, 75));
    JButton but13 = new JButton (image13);
   // but13.setPreferredSize(new Dimension (100,35));
    but13.addActionListener(new ActionRadium());
    cell13.add(but13);
    
    // troisième colonne
    
    JPanel cell14 = new JPanel();
    BufferedImage myPicture14 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Sc.png"));
	ImageIcon image14 = new ImageIcon(myPicture14);
    //cell14.setPreferredSize(new Dimension(150, 75));
    JButton but14 = new JButton (image14);
    //but14.setPreferredSize(new Dimension (100,35));
    but14.addActionListener(new ActionScandium());
    cell14.add(but14);
    
    JPanel cell15 = new JPanel();
    BufferedImage myPicture15 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Y.png"));
	ImageIcon image15 = new ImageIcon(myPicture15);
    //cell15.setPreferredSize(new Dimension(150, 75));
    JButton but15 = new JButton (image15);
    //but15.setPreferredSize(new Dimension (100,35));
    but15.addActionListener(new ActionYttrium());
    cell15.add(but15);
    
    JPanel cell16 = new JPanel();
    BufferedImage myPicture16 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/lanthanides.png"));
	ImageIcon image16 = new ImageIcon(myPicture16);
    //cell16.setPreferredSize(new Dimension(150, 75));
    JButton but16 = new JButton (image16);
    //but16.setPreferredSize(new Dimension (100,35));
    but16.addActionListener(new ActionLanthanides());
    cell16.add(but16);
			
    JPanel cell17 = new JPanel();
    BufferedImage myPicture17 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Actinides.png"));
	ImageIcon image17 = new ImageIcon(myPicture17);
    //cell17.setPreferredSize(new Dimension(150, 75));
    JButton but17 = new JButton (image17);
    //but17.setPreferredSize(new Dimension (100,35));
    but17.addActionListener(new ActionActinides());
    cell17.add(but17);
    
    //quatrième colonne
    
    JPanel cell18 = new JPanel();
    BufferedImage myPicture18 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ti.png"));
	ImageIcon image18 = new ImageIcon(myPicture18);
    //cell18.setPreferredSize(new Dimension(150, 75));
    JButton but18 = new JButton (image18);
    //but18.setPreferredSize(new Dimension (100,35));
    but18.addActionListener(new ActionTitane());
    cell18.add(but18);
    
    JPanel cell19 = new JPanel();
    BufferedImage myPicture19 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Zr.png"));
	ImageIcon image19 = new ImageIcon(myPicture19);
    //cell19.setPreferredSize(new Dimension(150, 75));
    JButton but19 = new JButton (image19);
    //but19.setPreferredSize(new Dimension (100,35));
    but18.addActionListener(new ActionZirconcium());
    cell19.add(but19);
    
    JPanel cell20 = new JPanel();
    BufferedImage myPicture20 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Hf.png"));
	ImageIcon image20 = new ImageIcon(myPicture20);
    //cell20.setPreferredSize(new Dimension(150, 75));
    JButton but20 = new JButton (image20);
    //but20.setPreferredSize(new Dimension (100,35));
    but20.addActionListener(new ActionHafnium());
    cell20.add(but20);
    
    JPanel cell21 = new JPanel();
    BufferedImage myPicture21 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Rf.png"));
	ImageIcon image21 = new ImageIcon(myPicture21);
    //cell21.setPreferredSize(new Dimension(150, 75));
    JButton but21 = new JButton (image21);
    //but21.setPreferredSize(new Dimension (100,35));
    but21.addActionListener(new ActionRutherfordium());
    cell21.add(but21);
    
    // cinquième colonne
    
    JPanel cell22 = new JPanel();
    BufferedImage myPicture22 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/V.png"));
	ImageIcon image22 = new ImageIcon(myPicture22);
    //cell22.setPreferredSize(new Dimension(150, 75));
    JButton but22 = new JButton (image22);
    //but22.setPreferredSize(new Dimension (100,35));
    but22.addActionListener(new ActionVanadium());
    cell22.add(but22);
    
    JPanel cell23 = new JPanel();
    BufferedImage myPicture23 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Nb.png"));
	ImageIcon image23 = new ImageIcon(myPicture23);
    //cell23.setPreferredSize(new Dimension(150, 75));
    JButton but23 = new JButton (image23);
    //but23.setPreferredSize(new Dimension (100,35));
    but23.addActionListener(new ActionNobium());
    cell23.add(but23);
    
    JPanel cell24 = new JPanel();
    BufferedImage myPicture24 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ta.png"));
	ImageIcon image24 = new ImageIcon(myPicture24);
    //cell24.setPreferredSize(new Dimension(150, 75));
    JButton but24 = new JButton (image24);
    //but24.setPreferredSize(new Dimension (100,35));
    but24.addActionListener(new ActionTantale());
    cell24.add(but24);
    
    JPanel cell25 = new JPanel();
    BufferedImage myPicture25 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Db.png"));
	ImageIcon image25 = new ImageIcon(myPicture25);
    //cell25.setPreferredSize(new Dimension(150, 75));
    JButton but25 = new JButton (image25);
    //but25.setPreferredSize(new Dimension (100,35));
    but25.addActionListener(new ActionDubnium());
    cell25.add(but25);
    
    // sixième colonne
    
    JPanel cell26 = new JPanel();
    BufferedImage myPicture26 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Cr.png"));
	ImageIcon image26 = new ImageIcon(myPicture26);
    //cell26.setPreferredSize(new Dimension(150, 75));
    JButton but26 = new JButton (image26);
    //but26.setPreferredSize(new Dimension (100,35));
    but26.addActionListener(new ActionChrome());
    cell26.add(but26);
    
    JPanel cell27 = new JPanel();
    BufferedImage myPicture27 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Mo.png"));
	ImageIcon image27 = new ImageIcon(myPicture27);
    //cell27.setPreferredSize(new Dimension(150, 75));
    JButton but27 = new JButton (image27);
    //but27.setPreferredSize(new Dimension (100,35));
    but27.addActionListener(new ActionMolibd�ne());
    cell27.add(but27);
    
    JPanel cell28 = new JPanel();
    BufferedImage myPicture28 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/W.png"));
	ImageIcon image28 = new ImageIcon(myPicture28);
    //cell28.setPreferredSize(new Dimension(150, 75));
    JButton but28 = new JButton (image28);
    //but28.setPreferredSize(new Dimension (100,35));
    but28.addActionListener(new ActionTungst�ne());
    cell28.add(but28);
    
    JPanel cell29 = new JPanel();
    BufferedImage myPicture29 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Sg.png"));
	ImageIcon image29 = new ImageIcon(myPicture29);
    //cell29.setPreferredSize(new Dimension(150, 75));
    JButton but29 = new JButton (image29);
    //but29.setPreferredSize(new Dimension (100,35));
    but29.addActionListener(new ActionSeaborgium());
    cell29.add(but29);
    
    // septième colonne
    
    JPanel cell30 = new JPanel();
    BufferedImage myPicture30 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Mn.png"));
	ImageIcon image30 = new ImageIcon(myPicture30);
    //cell30.setPreferredSize(new Dimension(150, 75));
    JButton but30 = new JButton (image30);
    //but30.setPreferredSize(new Dimension (100,35));
    but30.addActionListener(new ActionMangan�se());
    cell30.add(but30);
    
    JPanel cell31 = new JPanel();
    BufferedImage myPicture31 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Tc.png"));
	ImageIcon image31 = new ImageIcon(myPicture31);
    //cell31.setPreferredSize(new Dimension(150, 75));
    JButton but31 = new JButton (image31);
    //but31.setPreferredSize(new Dimension (100,35));
    but31.addActionListener(new ActionTecht�nium());
    cell31.add(but31);
    
    JPanel cell32 = new JPanel();
    BufferedImage myPicture32 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Re.png"));
	ImageIcon image32 = new ImageIcon(myPicture32);
    //cell32.setPreferredSize(new Dimension(150, 75));
    JButton but32 = new JButton (image32);
    //but32.setPreferredSize(new Dimension (100,35));
    cell32.add(but32);
    
    JPanel cell33 = new JPanel();
    BufferedImage myPicture33 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Bh.png"));
	ImageIcon image33 = new ImageIcon(myPicture33);
    //cell33.setPreferredSize(new Dimension(150, 75));
    JButton but33 = new JButton (image33);
    //but33.setPreferredSize(new Dimension (100,35));
    cell33.add(but33);
    
    //huitième colonne
    
    JPanel cell34 = new JPanel();
    BufferedImage myPicture34 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Fe.png"));
	ImageIcon image34 = new ImageIcon(myPicture34);
    //cell34.setPreferredSize(new Dimension(150, 75));
    JButton but34 = new JButton (image34);
    //but34.setPreferredSize(new Dimension (100,35));
    cell34.add(but34);
    
    JPanel cell35 = new JPanel();
    BufferedImage myPicture35 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ru.png"));
	ImageIcon image35 = new ImageIcon(myPicture35);
    //cell35.setPreferredSize(new Dimension(150, 75));
    JButton but35 = new JButton (image35);
    //but35.setPreferredSize(new Dimension (100,35));
    cell35.add(but35);
    
    JPanel cell36 = new JPanel();
    BufferedImage myPicture36 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Os.png"));
	ImageIcon image36 = new ImageIcon(myPicture36);
    //cell36.setPreferredSize(new Dimension(150, 75));
    JButton but36 = new JButton (image36);
    //but36.setPreferredSize(new Dimension (100,35));
    cell36.add(but36);
    
    JPanel cell37 = new JPanel();
    BufferedImage myPicture37 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Hs.png"));
	ImageIcon image37 = new ImageIcon(myPicture37);
    //cell37.setPreferredSize(new Dimension(150, 75));
    JButton but37 = new JButton (image37);
    //but37.setPreferredSize(new Dimension (100,35));
    cell37.add(but37);
    
    //neuvieme colonnne
    
    JPanel cell38 = new JPanel();
    BufferedImage myPicture38 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Co.png"));
	ImageIcon image38 = new ImageIcon(myPicture38);
    //cell38.setPreferredSize(new Dimension(150, 75));
    JButton but38 = new JButton (image38);
    //but38.setPreferredSize(new Dimension (100,35));
    cell38.add(but38);
    
    JPanel cell39 = new JPanel();
    BufferedImage myPicture39 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Rh.png"));
	ImageIcon image39 = new ImageIcon(myPicture39);
    //cell39.setPreferredSize(new Dimension(150, 75));
    JButton but39 = new JButton (image39);
    //but39.setPreferredSize(new Dimension (100,35));
    cell39.add(but39);
    
    JPanel cell40 = new JPanel();
    BufferedImage myPicture40 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ir.png"));
	ImageIcon image40 = new ImageIcon(myPicture40);
    //cell40.setPreferredSize(new Dimension(150, 75));
    JButton but40 = new JButton (image40);
    //but40.setPreferredSize(new Dimension (100,35));
    cell40.add(but40);
    
    JPanel cell41 = new JPanel();
    BufferedImage myPicture41 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Mt.png"));
	ImageIcon image41 = new ImageIcon(myPicture41);
    //cell41.setPreferredSize(new Dimension(150, 75));
    JButton but41 = new JButton (image41);
    //but41.setPreferredSize(new Dimension (100,35));
    cell41.add(but41);
    
    //dixième colonnne
    
    JPanel cell42 = new JPanel();
    BufferedImage myPicture42 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ni.png"));
	ImageIcon image42 = new ImageIcon(myPicture42);
    //cell42.setPreferredSize(new Dimension(150, 75));
    JButton but42 = new JButton (image42);
    //but42.setPreferredSize(new Dimension (100,35));
    cell42.add(but42);
    
    JPanel cell43 = new JPanel();
    BufferedImage myPicture43 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Pd.png"));
	ImageIcon image43 = new ImageIcon(myPicture43);
    //cell43.setPreferredSize(new Dimension(150, 75));
    JButton but43 = new JButton (image43);
    //but43.setPreferredSize(new Dimension (100,35));
    cell43.add(but43);
    
    JPanel cell44 = new JPanel();
    BufferedImage myPicture44 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Pt.png"));
	ImageIcon image44 = new ImageIcon(myPicture44);
    //cell44.setPreferredSize(new Dimension(150, 75));
    JButton but44 = new JButton (image44);
    //but44.setPreferredSize(new Dimension (100,35));
    cell44.add(but44);
    
    JPanel cell45 = new JPanel();
    BufferedImage myPicture45 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ds.png"));
	ImageIcon image45 = new ImageIcon(myPicture45);
    //cell45.setPreferredSize(new Dimension(150, 75));
    JButton but45 = new JButton (image45);
    //but45.setPreferredSize(new Dimension (100,35));
    cell45.add(but45);
    
    // onzième colonne
    
    JPanel cell46 = new JPanel();
    BufferedImage myPicture46 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Cu.png"));
	ImageIcon image46 = new ImageIcon(myPicture46);
    //cell46.setPreferredSize(new Dimension(150, 75));
    JButton but46 = new JButton (image46);
    //but46.setPreferredSize(new Dimension (100,35));
    cell46.add(but46);
    
    JPanel cell47 = new JPanel();
    BufferedImage myPicture47 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ag.png"));
	ImageIcon image47 = new ImageIcon(myPicture47);
    //cell47.setPreferredSize(new Dimension(150, 75));
    JButton but47 = new JButton (image47);
    //but47.setPreferredSize(new Dimension (100,35));
    cell47.add(but47);
    
    JPanel cell48 = new JPanel();
    BufferedImage myPicture48 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Au.png"));
	ImageIcon image48 = new ImageIcon(myPicture48);
    //cell48.setPreferredSize(new Dimension(150, 75));
    JButton but48 = new JButton (image48);
    //but48.setPreferredSize(new Dimension (100,35));
    cell48.add(but48);
    
    JPanel cell49 = new JPanel();
    BufferedImage myPicture49 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Rg.png"));
	ImageIcon image49 = new ImageIcon(myPicture49);
    //cell49.setPreferredSize(new Dimension(150, 75));
    JButton but49 = new JButton (image49);
    //but49.setPreferredSize(new Dimension (100,35));
    cell49.add(but49);
    
    //douzième colonnne
    
    JPanel cell50 = new JPanel();
    BufferedImage myPicture50 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Zn.png"));
	ImageIcon image50 = new ImageIcon(myPicture50);
    //cell50.setPreferredSize(new Dimension(150, 75));
    JButton but50 = new JButton (image50);
    //but50.setPreferredSize(new Dimension (100,35));
    cell50.add(but50);
    
    JPanel cell51 = new JPanel();
    BufferedImage myPicture51 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Cd.png"));
	ImageIcon image51 = new ImageIcon(myPicture51);
    //cell51.setPreferredSize(new Dimension(150, 75));
    JButton but51 = new JButton (image51);
    //but51.setPreferredSize(new Dimension (100,35));
    cell51.add(but51);
    
    JPanel cell52 = new JPanel();
    BufferedImage myPicture52 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Hg.png"));
	ImageIcon image52 = new ImageIcon(myPicture52);
    //cell52.setPreferredSize(new Dimension(150, 75));
    JButton but52 = new JButton (image52);
    //but52.setPreferredSize(new Dimension (100,35));
    cell52.add(but52);
    
    JPanel cell53 = new JPanel();
    BufferedImage myPicture53 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Cn.png"));
	ImageIcon image53 = new ImageIcon(myPicture53);
    //cell53.setPreferredSize(new Dimension(150, 75));
    JButton but53 = new JButton (image53);
    //but53.setPreferredSize(new Dimension (100,35));
    cell53.add(but53);
    
    //trezi�me colonne
    JPanel cell54 = new JPanel();
    BufferedImage myPicture54 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/B.png"));
	ImageIcon image54 = new ImageIcon(myPicture54);
    //cell54.setPreferredSize(new Dimension(150, 75));
    JButton but54 = new JButton (image54);
    //but54.setPreferredSize(new Dimension (100,35));
    cell54.add(but54);
    
    JPanel cell55 = new JPanel();
    BufferedImage myPicture55 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Al.png"));
	ImageIcon image55 = new ImageIcon(myPicture55);
    //cell55.setPreferredSize(new Dimension(150, 75));
    JButton but55 = new JButton (image55);
    //but55.setPreferredSize(new Dimension (100,35));
    cell55.add(but55);
    
    JPanel cell56 = new JPanel();
    BufferedImage myPicture56 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ga.png"));
	ImageIcon image56 = new ImageIcon(myPicture56);
    //cell56.setPreferredSize(new Dimension(150, 75));
    JButton but56 = new JButton (image56);
    //but56.setPreferredSize(new Dimension (100,35));
    cell56.add(but56);
    
    JPanel cell57 = new JPanel();
    BufferedImage myPicture57 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/In.png"));
	ImageIcon image57 = new ImageIcon(myPicture57);
    //cell57.setPreferredSize(new Dimension(150, 75));
    JButton but57 = new JButton (image57);
    //but57.setPreferredSize(new Dimension (100,35));
    cell57.add(but57);
    
    JPanel cell58 = new JPanel();
    BufferedImage myPicture58 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Tl.png"));
	ImageIcon image58 = new ImageIcon(myPicture58);
    //cell58.setPreferredSize(new Dimension(150, 75));
    JButton but58 = new JButton (image58);
    //but58.setPreferredSize(new Dimension (100,35));
    cell58.add(but58);
    
    JPanel cell59 = new JPanel();
    BufferedImage myPicture59 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Nh.png"));
	ImageIcon image59 = new ImageIcon(myPicture59);
    //cell59.setPreferredSize(new Dimension(150, 75));
    JButton but59 = new JButton (image59);
    //but59.setPreferredSize(new Dimension (100,35));
    cell59.add(but59);
    
    // Quatorzi�me colonne
    JPanel cell60 = new JPanel();
    BufferedImage myPicture60 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/C.png"));
	ImageIcon image60 = new ImageIcon(myPicture60);
    //cell60.setPreferredSize(new Dimension(150, 75));
    JButton but60 = new JButton (image60);
    //but60.setPreferredSize(new Dimension (100,35));
    cell60.add(but60);
    
    JPanel cell61 = new JPanel();
    BufferedImage myPicture61 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Si.png"));
	ImageIcon image61 = new ImageIcon(myPicture61);
    //cell61.setPreferredSize(new Dimension(150, 75));
    JButton but61 = new JButton (image61);
    //but61.setPreferredSize(new Dimension (100,35));
    cell61.add(but61);
    
    JPanel cell62 = new JPanel();
    BufferedImage myPicture62 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ge.png"));
	ImageIcon image62 = new ImageIcon(myPicture62);
    //cell62.setPreferredSize(new Dimension(150, 75));
    JButton but62 = new JButton (image62);
    //but62.setPreferredSize(new Dimension (100,35));
    cell62.add(but62);
    
    JPanel cell63 = new JPanel();
    BufferedImage myPicture63 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Sn.png"));
	ImageIcon image63 = new ImageIcon(myPicture63);
    //cell63.setPreferredSize(new Dimension(150, 75));
    JButton but63 = new JButton (image63);
    //but63.setPreferredSize(new Dimension (100,35));
    cell63.add(but63);
    
    JPanel cell64 = new JPanel();
    BufferedImage myPicture64 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Pb.png"));
	ImageIcon image64 = new ImageIcon(myPicture64);
    //cell64.setPreferredSize(new Dimension(150, 75));
    JButton but64 = new JButton (image64);
    //but64.setPreferredSize(new Dimension (100,35));
    cell64.add(but64);
    
    JPanel cell65 = new JPanel();
    BufferedImage myPicture65 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Fl.png"));
	ImageIcon image65 = new ImageIcon(myPicture65);
    //cell65.setPreferredSize(new Dimension(150, 75));
    JButton but65 = new JButton (image65);
    //but65.setPreferredSize(new Dimension (100,35));
    cell65.add(but65);
    
    //Quinzi�me colonne
    JPanel cell66 = new JPanel();
    BufferedImage myPicture66 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/N.png"));
	ImageIcon image66 = new ImageIcon(myPicture66);
    //cell66.setPreferredSize(new Dimension(150, 75));
    JButton but66 = new JButton (image66);
    //but66.setPreferredSize(new Dimension (100,35));
    cell66.add(but66);
    
    JPanel cell67 = new JPanel();
    BufferedImage myPicture67 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/P.png"));
	ImageIcon image67 = new ImageIcon(myPicture67);
    //cell67.setPreferredSize(new Dimension(150, 75));
    JButton but67 = new JButton (image67);
    //but67.setPreferredSize(new Dimension (100,35));
    cell67.add(but67);
    
    JPanel cell68 = new JPanel();
    BufferedImage myPicture68 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/As.png"));
	ImageIcon image68 = new ImageIcon(myPicture68);
    //cell68.setPreferredSize(new Dimension(150, 75));
    JButton but68 = new JButton (image68);
    //but68.setPreferredSize(new Dimension (100,35));
    cell68.add(but68);
    
    JPanel cell69 = new JPanel();
    BufferedImage myPicture69 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Sb.png"));
	ImageIcon image69 = new ImageIcon(myPicture69);
    //cell69.setPreferredSize(new Dimension(150, 75));
    JButton but69 = new JButton (image69);
    //but69.setPreferredSize(new Dimension (100,35));
    cell69.add(but69);
    
    JPanel cell70 = new JPanel();
    BufferedImage myPicture70 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Bi.png"));
	ImageIcon image70 = new ImageIcon(myPicture70);
    //cell70.setPreferredSize(new Dimension(150, 75));
    JButton but70 = new JButton (image70);
    //but70.setPreferredSize(new Dimension (100,35));
    cell70.add(but70);
    
    JPanel cell71 = new JPanel();
    BufferedImage myPicture71 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Mc.png"));
	ImageIcon image71 = new ImageIcon(myPicture71);
    //cell71.setPreferredSize(new Dimension(150, 75));
    JButton but71 = new JButton (image71);
    //but71.setPreferredSize(new Dimension (100,35));
    cell71.add(but71);
    
  //sezi�me colonne
    JPanel cell72 = new JPanel();
    BufferedImage myPicture72 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/O.png"));
	ImageIcon image72 = new ImageIcon(myPicture72);
    //cell72.setPreferredSize(new Dimension(150, 75));
    JButton but72 = new JButton (image72);
    //but72.setPreferredSize(new Dimension (100,35));
    cell72.add(but72);
    
    JPanel cell73 = new JPanel();
    BufferedImage myPicture73 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/S.png"));
	ImageIcon image73 = new ImageIcon(myPicture73);
    //cell73.setPreferredSize(new Dimension(150, 75));
    JButton but73 = new JButton (image73);
    //but73.setPreferredSize(new Dimension (100,35));
    cell73.add(but73);
    
    JPanel cell74 = new JPanel();
    BufferedImage myPicture74 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Se.png"));
	ImageIcon image74 = new ImageIcon(myPicture74);
    //cell74.setPreferredSize(new Dimension(150, 75));
    JButton but74 = new JButton (image74);
    //but74.setPreferredSize(new Dimension (100,35));
    cell74.add(but74);
    
    JPanel cell75 = new JPanel();
    BufferedImage myPicture75 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Te.png"));
	ImageIcon image75 = new ImageIcon(myPicture75);
    //cell75.setPreferredSize(new Dimension(150, 75));
    JButton but75 = new JButton (image75);
    //but75.setPreferredSize(new Dimension (100,35));
    cell75.add(but75);
    
    JPanel cell76 = new JPanel();
    BufferedImage myPicture76 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Po.png"));
	ImageIcon image76 = new ImageIcon(myPicture76);
    //cell76.setPreferredSize(new Dimension(150, 75));
    JButton but76 = new JButton (image76);
    //but76.setPreferredSize(new Dimension (100,35));
    cell76.add(but76);
    
    JPanel cell77 = new JPanel();
    BufferedImage myPicture77 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Lv.png"));
	ImageIcon image77 = new ImageIcon(myPicture77);
    //cell77.setPreferredSize(new Dimension(150, 75));
    JButton but77 = new JButton (image77);
    //but77.setPreferredSize(new Dimension (100,35));
    cell77.add(but77);
    
  //17 colonne
    JPanel cell78 = new JPanel();
    BufferedImage myPicture78 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/F.png"));
	ImageIcon image78 = new ImageIcon(myPicture78);
    //cell78.setPreferredSize(new Dimension(150, 75));
    JButton but78 = new JButton (image78);
    //but78.setPreferredSize(new Dimension (100,35));
    cell78.add(but78);
    
    JPanel cell79 = new JPanel();
    BufferedImage myPicture79 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Cl.png"));
	ImageIcon image79 = new ImageIcon(myPicture79);
    //cell79.setPreferredSize(new Dimension(150, 75));
    JButton but79 = new JButton (image79);
    //but79.setPreferredSize(new Dimension (100,35));
    cell79.add(but79);
    
    JPanel cell80 = new JPanel();
    BufferedImage myPicture80 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Br.png"));
	ImageIcon image80 = new ImageIcon(myPicture80);
    //cell80.setPreferredSize(new Dimension(150, 75));
    JButton but80 = new JButton (image80);
    //but80.setPreferredSize(new Dimension (100,35));
    cell80.add(but80);
    
    JPanel cell81 = new JPanel();
    BufferedImage myPicture81 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/I.png"));
	ImageIcon image81 = new ImageIcon(myPicture81);
    //cell81.setPreferredSize(new Dimension(150, 75));
    JButton but81 = new JButton (image81);
    //but81.setPreferredSize(new Dimension (100,35));
    cell81.add(but81);
    
    JPanel cell82 = new JPanel();
    BufferedImage myPicture82 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/At.png"));
	ImageIcon image82 = new ImageIcon(myPicture82);
    //cell82.setPreferredSize(new Dimension(150, 75));
    JButton but82 = new JButton (image82);
    //but82.setPreferredSize(new Dimension (100,35));
    cell82.add(but82);
    
    JPanel cell83 = new JPanel();
    BufferedImage myPicture83 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ts.png"));
	ImageIcon image83 = new ImageIcon(myPicture83);
    //cell83.setPreferredSize(new Dimension(150, 75));
    JButton but83 = new JButton (image83);
    //but83.setPreferredSize(new Dimension (100,35));
    cell83.add(but83);
    
  //18 colonne
    JPanel cell84 = new JPanel();
    BufferedImage myPicture84 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/He.png"));
	ImageIcon image84 = new ImageIcon(myPicture84);
    //cell84.setPreferredSize(new Dimension(150, 75));
    JButton but84 = new JButton (image84);
    //but84.setPreferredSize(new Dimension (100,35));
    cell84.add(but84);
    
    JPanel cell85 = new JPanel();
    BufferedImage myPicture85 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ne.png"));
	ImageIcon image85 = new ImageIcon(myPicture85);
    //cell85.setPreferredSize(new Dimension(150, 75));
    JButton but85 = new JButton (image85);
    //but85.setPreferredSize(new Dimension (100,35));
    cell85.add(but85);
    
    JPanel cell86 = new JPanel();
    BufferedImage myPicture86 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Ar.png"));
	ImageIcon image86 = new ImageIcon(myPicture86);
    //cell86.setPreferredSize(new Dimension(150, 75));
    JButton but86 = new JButton (image86);
    //but86.setPreferredSize(new Dimension (100,35));
    cell86.add(but86);
    
    JPanel cell87 = new JPanel();
    BufferedImage myPicture87 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Kr.png"));
	ImageIcon image87 = new ImageIcon(myPicture87);
    //cell87.setPreferredSize(new Dimension(150, 75));
    JButton but87 = new JButton (image87);
    //but87.setPreferredSize(new Dimension (100,35));
    cell87.add(but87);
    
    JPanel cell88 = new JPanel();
    BufferedImage myPicture88 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Xe.png"));
	ImageIcon image88 = new ImageIcon(myPicture88);
    //cell88.setPreferredSize(new Dimension(150, 75));
    JButton but88 = new JButton (image88);
    //but88.setPreferredSize(new Dimension (100,35));
    cell88.add(but88);
    
    JPanel cell89 = new JPanel();
    BufferedImage myPicture89 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Rn.png"));
	ImageIcon image89 = new ImageIcon(myPicture89);
    //cell89.setPreferredSize(new Dimension(150, 75));
    JButton but89 = new JButton (image89);
    //but89.setPreferredSize(new Dimension (100,35));
    cell89.add(but89);
    
    JPanel cell90 = new JPanel();
    BufferedImage myPicture90 = ImageIO.read(new File("/Users/gulsu/git/GLP-laChimie/LaChimie/src/LaChimie/src/Chimie/imgAtome/Og.png"));
	ImageIcon image90 = new ImageIcon(myPicture90);
    //cell90.setPreferredSize(new Dimension(150, 75));
    JButton but90 = new JButton (image90);
    //but90.setPreferredSize(new Dimension (100,35));
    cell90.add(but90);

    /***
    // Avant derni�re ligne
    JPanel cell91 = new JPanel();
    cell91.setPreferredSize(new Dimension(150,75));
    JButton but91 = new JButton ("La");
    but91.setPreferredSize(new Dimension(150,75));
    cell91.add(but91);
   
    JPanel cell92 = new JPanel();
    cell92.setPreferredSize(new Dimension(150,75));
    JButton but92 = new JButton ("Ce");
    but92.setPreferredSize(new Dimension(150,75));
    cell92.add(but92);
    
    JPanel cell93 = new JPanel();
    cell93.setPreferredSize(new Dimension(150,75));
    JButton but93 = new JButton ("Pr");
    but93.setPreferredSize(new Dimension(150,75));
    cell93.add(but93);
    
    JPanel cell94 = new JPanel();
    cell94.setPreferredSize(new Dimension(150,75));
    JButton but94 = new JButton ("Nd");
    but94.setPreferredSize(new Dimension(150,75));
    cell94.add(but94);
    
    JPanel cell95 = new JPanel();
    cell95.setPreferredSize(new Dimension(150,75));
    JButton but95 = new JButton ("Pm");
    but95.setPreferredSize(new Dimension(150,75));
    cell95.add(but95);
    
    JPanel cell96 = new JPanel();
    cell96.setPreferredSize(new Dimension(150,75));
    JButton but96 = new JButton ("Sm");
    but96.setPreferredSize(new Dimension(150,75));
    cell96.add(but96);
    
    JPanel cell97 = new JPanel();
    cell97.setPreferredSize(new Dimension(150,75));
    JButton but97 = new JButton ("Eu");
    but91.setPreferredSize(new Dimension(150,75));
    cell97.add(but97);
    
    JPanel cell98 = new JPanel();
    cell98.setPreferredSize(new Dimension(150,75));
    JButton but98 = new JButton ("Gd");
    but98.setPreferredSize(new Dimension(150,75));
    cell98.add(but98);
    
    JPanel cell99 = new JPanel();
    cell99.setPreferredSize(new Dimension(150,75));
    JButton but99 = new JButton ("Tb");
    but99.setPreferredSize(new Dimension(150,75));
    cell99.add(but99);
    
    JPanel cell100 = new JPanel();
    cell100.setPreferredSize(new Dimension(150,75));
    JButton but100 = new JButton ("Dy");
    but100.setPreferredSize(new Dimension(150,75));
    cell100.add(but100);
    
    JPanel cell101 = new JPanel();
    cell101.setPreferredSize(new Dimension(150,75));
    JButton but101 = new JButton ("Ho");
    but101.setPreferredSize(new Dimension(150,75));
    cell101.add(but101);
    
    JPanel cell102 = new JPanel();
    cell102.setPreferredSize(new Dimension(150,75));
    JButton but102 = new JButton ("Er");
    but102.setPreferredSize(new Dimension(150,75));
    cell102.add(but102);
    
    JPanel cell103 = new JPanel();
    cell103.setPreferredSize(new Dimension(150,75));
    JButton but103 = new JButton ("Tm");
    but103.setPreferredSize(new Dimension(150,75));
    cell103.add(but103);
    
    JPanel cell104 = new JPanel();
    cell104.setPreferredSize(new Dimension(150,75));
    JButton but104 = new JButton ("Yb");
    but104.setPreferredSize(new Dimension(150,75));
    cell104.add(but104);
    
    JPanel cell105 = new JPanel();
    cell105.setPreferredSize(new Dimension(150,75));
    JButton but105 = new JButton ("Lu");
    but105.setPreferredSize(new Dimension(150,75));
    cell105.add(but105);
    
 // Derni�re ligne
    JPanel cell106 = new JPanel();
    cell106.setPreferredSize(new Dimension(150,75));
    JButton but106 = new JButton ("Ac");
    but106.setPreferredSize(new Dimension(150,75));
    cell106.add(but106);
   
    JPanel cell107 = new JPanel();
    cell107.setPreferredSize(new Dimension(150,75));
    JButton but107 = new JButton ("Th");
    but107.setPreferredSize(new Dimension(150,75));
    cell107.add(but107);
    
    JPanel cell108 = new JPanel();
    cell108.setPreferredSize(new Dimension(150,75));
    JButton but108 = new JButton ("Pa");
    but108.setPreferredSize(new Dimension(150,75));
    cell108.add(but108);
    
    JPanel cell109 = new JPanel();
    cell109.setPreferredSize(new Dimension(150,75));
    JButton but109 = new JButton ("U");
    but109.setPreferredSize(new Dimension(150,75));
    cell109.add(but109);
    
    JPanel cell110 = new JPanel();
    cell110.setPreferredSize(new Dimension(150,75));
    JButton but110 = new JButton ("Np");
    but110.setPreferredSize(new Dimension(150,75));
    cell110.add(but110);
    
    JPanel cell111 = new JPanel();
    cell111.setPreferredSize(new Dimension(150,75));
    JButton but111 = new JButton ("Pu");
    but111.setPreferredSize(new Dimension(150,75));
    cell111.add(but111);
    
    JPanel cell112 = new JPanel();
    cell112.setPreferredSize(new Dimension(150,75));
    JButton but112 = new JButton ("Am");
    but112.setPreferredSize(new Dimension(150,75));
    cell112.add(but112);
    
    JPanel cell113 = new JPanel();
    cell113.setPreferredSize(new Dimension(150,75));
    JButton but113 = new JButton ("Cm");
    but113.setPreferredSize(new Dimension(150,75));
    cell113.add(but113);
    
    JPanel cell114 = new JPanel();
    cell114.setPreferredSize(new Dimension(150,75));
    JButton but114 = new JButton ("Bk");
    but114.setPreferredSize(new Dimension(150,75));
    cell114.add(but114);
    
    JPanel cell115 = new JPanel();
    cell115.setPreferredSize(new Dimension(150,75));
    JButton but115 = new JButton ("Cf");
    but115.setPreferredSize(new Dimension(150,75));
    cell115.add(but115);
    
    JPanel cell116 = new JPanel();
    cell116.setPreferredSize(new Dimension(150,75));
    JButton but116 = new JButton ("Es");
    but116.setPreferredSize(new Dimension(150,75));
    cell116.add(but116);
    
    JPanel cell117 = new JPanel();
    cell117.setPreferredSize(new Dimension(150,75));
    JButton but117 = new JButton ("Fm");
    but117.setPreferredSize(new Dimension(150,75));
    cell117.add(but117);
    
    JPanel cell118 = new JPanel();
    cell118.setPreferredSize(new Dimension(150,75));
    JButton but118 = new JButton ("Md");
    but118.setPreferredSize(new Dimension(150,75));
    cell118.add(but118);
    
    JPanel cell119 = new JPanel();
    cell119.setPreferredSize(new Dimension(150,75));
    JButton but119 = new JButton ("No");
    but119.setPreferredSize(new Dimension(150,75));
    cell119.add(but119);
    
    JPanel cell120 = new JPanel();
    cell120.setPreferredSize(new Dimension(150,75));
    JButton but120 = new JButton ("Lr");
    but120.setPreferredSize(new Dimension(150,75));
    cell120.add(but120);
    
    ***/
    
    
    
    
    
    
		
    //Le conteneur principal
    JPanel content = new JPanel();
    //content.setPreferredSize(new Dimension(10000, 500));
    content.setBackground(Color.WHITE);
    content.setLayout(new GridBagLayout());
    //L'objet servant à positionner les composants
    GridBagConstraints gbc = new GridBagConstraints();
	
	
    //première colonne
    
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell1, gbc);
    //---------------------------------------------
   
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell2, gbc);
    //---------------------------------------------
    
    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell3, gbc);
    //---------------------------------------------
    
    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell4, gbc);
    //---------------------------------------------
    
    gbc.gridx = 0;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell5, gbc);
    //---------------------------------------------
    
    gbc.gridx = 0;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell6, gbc);
    //---------------------------------------------
    
    gbc.gridx = 0;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell7, gbc);
    //---------------------------------------------
    
    //deuxième colonne
    
    gbc.gridx = 1;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell8, gbc);
    //---------------------------------------------
  
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell9, gbc);
    //---------------------------------------------
    
    gbc.gridx = 1;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell10, gbc);
    //---------------------------------------------
    
    gbc.gridx = 1;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell11, gbc);
    //---------------------------------------------
    
    gbc.gridx = 1;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell12, gbc);
    //---------------------------------------------
    
    gbc.gridx = 1;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell13, gbc);
    //---------------------------------------------
    
    //troisieme colonne
    
    gbc.gridx = 2;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell14, gbc);
    //---------------------------------------------
    
    gbc.gridx = 2;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell15, gbc);
    //---------------------------------------------
    
    gbc.gridx = 2;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell16, gbc);
    //---------------------------------------------
    
    gbc.gridx = 2;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell17, gbc);
    //---------------------------------------------
    
    //quatrième colonne
    
    gbc.gridx = 3;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell18, gbc);
    //---------------------------------------------
    
    gbc.gridx = 3;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell19, gbc);
    //---------------------------------------------
    
    gbc.gridx = 3;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell20, gbc);
    //---------------------------------------------
    
    gbc.gridx = 3;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell21, gbc);
    //---------------------------------------------
    
    //cinquième colonne
    
    gbc.gridx = 4;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell22, gbc);
    //---------------------------------------------
    
    gbc.gridx = 4;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell23, gbc);
    //---------------------------------------------
    
    gbc.gridx = 4;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell24, gbc);
    //---------------------------------------------
    
    gbc.gridx = 4;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell25, gbc);
    //---------------------------------------------
    
    //sixième colonne
    
    gbc.gridx = 5;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell26, gbc);
    //---------------------------------------------
    
    gbc.gridx = 5;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell27, gbc);
    //---------------------------------------------
    
    gbc.gridx = 5;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell28, gbc);
    //---------------------------------------------
    
    gbc.gridx = 5;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell29, gbc);
    //---------------------------------------------
    
    //septième colonne
    
    gbc.gridx = 6;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell30, gbc);
    //---------------------------------------------
    
    gbc.gridx = 6;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell31, gbc);
    //---------------------------------------------
    
    gbc.gridx = 6;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell32, gbc);
    //---------------------------------------------
    
    gbc.gridx = 6;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell33, gbc);
    //---------------------------------------------
    
    //huitième colonne
    
    gbc.gridx = 7;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell34, gbc);
    //---------------------------------------------
    
    gbc.gridx = 7;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell35, gbc);
    //---------------------------------------------
    
    gbc.gridx = 7;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell36, gbc);
    //---------------------------------------------
    
    gbc.gridx = 7;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell37, gbc);
    //---------------------------------------------
    
    // neuvieme colonnne
    
    gbc.gridx = 8;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell38, gbc);
    //---------------------------------------------
    
    gbc.gridx = 8;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell39, gbc);
    //---------------------------------------------
    
    gbc.gridx = 8;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell40, gbc);
    //---------------------------------------------
    
    gbc.gridx = 8;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell41, gbc);
    //---------------------------------------------
    
  //dixième colonnne
    
    gbc.gridx = 9;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell42, gbc);
    //---------------------------------------------
    
    gbc.gridx = 9;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell43, gbc);
    //---------------------------------------------
    
    gbc.gridx = 9;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell44, gbc);
    //---------------------------------------------
    
    gbc.gridx = 9;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell45, gbc);
    //---------------------------------------------
    
 // onzième colonne
    
    gbc.gridx = 10;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell46, gbc);
    //---------------------------------------------
    
    gbc.gridx = 10;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell47, gbc);
    //---------------------------------------------
    
    gbc.gridx = 10;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell48, gbc);
    //---------------------------------------------
    
    gbc.gridx = 10;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell49, gbc);
    //---------------------------------------------
    
    //douzième colonne
    
    gbc.gridx = 11;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell50, gbc);
    //---------------------------------------------
    
    gbc.gridx = 11;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell51, gbc);
    //---------------------------------------------
    
    gbc.gridx = 11;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell52, gbc);
    //---------------------------------------------
    
    gbc.gridx = 11;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell53, gbc);
    //---------------------------------------------
    
    //tresi�me colonne
    gbc.gridx = 12;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell54, gbc);
   
    //-----------------------------------------------
    gbc.gridx = 12;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell55, gbc);
    
    //-----------------------------------------------
    gbc.gridx = 12;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell56, gbc);
    
    //-----------------------------------------------
    gbc.gridx = 12;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell57, gbc);
    
    //-----------------------------------------------
    gbc.gridx = 12;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell58, gbc);
    
    //------------------------------------------------
    gbc.gridx = 12;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell59, gbc);
    
    //--------------------------------------------------
    
    //quatorzi�me colonne
    gbc.gridx = 13;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell60, gbc);
    
    //-------------------------------------------------
    gbc.gridx = 13;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell61, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 13;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell62, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 13;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell63, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 13;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell64, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 13;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell65, gbc);
    
  //-------------------------------------------------

    //Quinzi�me colonne
    
    gbc.gridx = 14;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell66, gbc);
    
    //-------------------------------------------------
    gbc.gridx = 14;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell67, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 14;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell68, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 14;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell69, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 14;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell70, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 14;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell71, gbc);
    
  //-------------------------------------------------
    
//Sezi�me colonne
    
    gbc.gridx = 15;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell72, gbc);
    
    //-------------------------------------------------
    gbc.gridx = 15;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell73, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 15;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell74, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 15;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell75, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 15;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell76, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 15;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell77, gbc);
    
  //-------------------------------------------------
    
//17 colonne
    
    gbc.gridx = 16;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell78, gbc);
    
    //-------------------------------------------------
    gbc.gridx = 16;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell79, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 16;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell80, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 16;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell81, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 16;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell82, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 16;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell83, gbc);
    
  //-------------------------------------------------
    
//18 colonne
    
    gbc.gridx = 17;
    gbc.gridy = 0;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell84, gbc);
    
    //-------------------------------------------------
    gbc.gridx = 17;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell85, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 17;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell86, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 17;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell87, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 17;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell88, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 17;
    gbc.gridy = 5;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell89, gbc);
    
  //-------------------------------------------------
    gbc.gridx = 17;
    gbc.gridy = 6;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell90, gbc);
    
  //-------------------------------------------------
   
    /*********
    //Avant derni�re ligne
    gbc.gridx = 3;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell91, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 4;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell92, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 5;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell93, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 6;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell94, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 7;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell95, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 8;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell96, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 9;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell97, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 10;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell98, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 11;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell99, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 12;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell100, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 13;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell101, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 14;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell102, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 15;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell103, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 16;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell104, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 17;
    gbc.gridy = 8;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell105, gbc);
   //------------------------------------------------- 
    
  //Derni�re ligne
    gbc.gridx = 3;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell106, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 4;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell107, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 5;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell108, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 6;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell109, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 7;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell110, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 8;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell111, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 9;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell112, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 10;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell113, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 11;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell114, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 12;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell115, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 13;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell116, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 14;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell117, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 15;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell118, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 16;
    gbc.gridy = 10;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell119, gbc);
   //------------------------------------------------- 
    
    gbc.gridx = 17;
    gbc.gridy = 9;
    gbc.gridheight = 1;
    gbc.gridwidth = 1;
    content.add(cell120, gbc);
   //------------------------------------------------- 
    ****/
    
    this.setContentPane(content);    
    this.setVisible(true);		
  }
}