package Chimie;

public class Calcule {
	private Atome atome;
	private Molecule molecule;
		
	public Calcule(Atome atome, Molecule molecule) {
		this.atome = atome;
		this.molecule = molecule;
	}
	
	public double MasseMolaire(Molecule molecule) {
		double Mm = 0;
		return Mm;
	
	}
}
