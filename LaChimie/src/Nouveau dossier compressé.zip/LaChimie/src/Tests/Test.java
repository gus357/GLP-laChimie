package Tests;

import java.io.IOException;

import Chimie.TableMende;

public class Test {
	
	public static void main (String [] args) throws IOException {
		
		//Fenetre fen = new Fenetre("tableau de mendeliev");
	//	fen.init();
		
		TableMende u = new TableMende();
		
	}

}
