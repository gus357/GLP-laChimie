package Tests;

import Chimie.Accueil;

public class TestAccueil {
	
	public static void main (String[]args) {
		Accueil ac =new Accueil();
	}
}