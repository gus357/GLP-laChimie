package Tests;

import Chimie.Molecule;

public class Test1 {
	public static void main(String[] args) throws Exception {
		Molecule m = new Molecule();
	}
}
